

public enum Direction { None = -1, Right = 0, Up, Left, Down, Count }
